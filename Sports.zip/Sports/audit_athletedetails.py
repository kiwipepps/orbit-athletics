from db_utils import supabase
import re
import json
import time
import random

# ===========================
# CONFIGURATION
# ===========================
COMMIT_CHANGES = True  # 🔴 Set to True to write to database
BATCH_SIZE = 1000

# 🟢 NEW: Retry Helper
def update_with_retry(table, data, record_id, retries=3):
    """
    Tries to update the database. If it fails (connection error),
    it waits and tries again up to 3 times.
    """
    for attempt in range(retries):
        try:
            supabase.table(table).update(data).eq("id", record_id).execute()
            return True # Success
        except Exception as e:
            print(f"      ⚠️ Connection error on attempt {attempt+1}/{retries}: {e}")
            if attempt < retries - 1:
                time.sleep(5) # Wait 5 seconds before retrying
            else:
                print(f"      ❌ Failed to update ID {record_id} after {retries} attempts.")
                return False

def standardize_event_name(name):
    name = name.lower().strip()
    
    # 1. Shortcode Mapping
    if name in ["sp", "shotput", "shot-put"]: return "Shot Put"
    if name in ["dt", "discus"]: return "Discus"
    if name in ["jt", "javelin", "javelin-throw"]: return "Javelin"
    if name in ["ht", "hammer", "hammer-throw"]: return "Hammer Throw"
    if name in ["lj", "longjump", "long-jump"]: return "Long Jump"
    if name in ["tj", "triplejump", "triple-jump"]: return "Triple Jump"
    if name in ["hj", "highjump", "high-jump"]: return "High Jump"
    if name in ["pv", "polevault", "pole-vault"]: return "Pole Vault"
    if name in ["wt", "weightthrow", "weight-throw"]: return "Weight Throw"
    
    # Hurdles
    if name in ["110mh", "110m-hurdles"]: return "110mH"
    if name in ["100mh", "100m-hurdles"]: return "100mH"
    if name in ["400mh", "400m-hurdles"]: return "400mH"
    
    # Walks
    if "walk" in name:
        if "20km" in name: return "20km Walk"
        if "35km" in name: return "35km Walk"
        if "50km" in name: return "50km Walk"
        name = name.replace("walk", " Walk")

    # 2. Distance Formatting
    match = re.match(r"^(\d+)m", name)
    if match:
        dist = int(match.group(1))
        formatted_dist = f"{dist:,}m"
        suffix = name[len(match.group(1)):] 
        if suffix.strip() == "m": suffix = "" 
        return formatted_dist + suffix

    # Combined & Road
    if "decathlon" in name: return "Decathlon"
    if "heptathlon" in name: return "Heptathlon"
    if "pentathlon" in name: return "Pentathlon"
    if name == "xc": return "XC"
    if "halfmarathon" in name or "half-marathon" in name: return "Half Marathon"
    if name == "marathon": return "Marathon"
    
    return name.title()

def clean_row_details(details):
    if not details or not isinstance(details, dict): return {}
    clean_data = {}

    for key, val in details.items():
        if "_" not in key: continue
        prefix, raw_event = key.split("_", 1)
        
        std_event = standardize_event_name(raw_event)
        new_key = f"{prefix}_{std_event}"
        
        # Merge Logic: Overwrite N/A with real data
        if new_key not in clean_data:
            clean_data[new_key] = val
        else:
            current_val = clean_data[new_key]
            if str(current_val).upper() in ["N/A", "NONE", ""] and str(val).upper() not in ["N/A", "NONE", ""]:
                clean_data[new_key] = val
                
    return clean_data

def run_cleanup():
    print(f"🧹 Starting Cleanup (Commit: {COMMIT_CHANGES})...")
    
    # 🟢 NEW: Allow resuming if it crashed at 14000
    start = 0 
    # start = 14000 # <-- UNCOMMENT THIS line if you want to skip the first 14k you already did
    
    total_cleaned = 0
    
    while True:
        try:
            print(f"   ...Fetching rows {start} to {start + BATCH_SIZE}")
            res = supabase.table("entities")\
                .select("id, name, details")\
                .not_.is_("details", "null")\
                .range(start, start + BATCH_SIZE - 1)\
                .execute()
            
            rows = res.data
            if not rows: break
            
            for row in rows:
                original = row['details']
                cleaned = clean_row_details(original)
                
                if json.dumps(original, sort_keys=True) != json.dumps(cleaned, sort_keys=True):
                    
                    if COMMIT_CHANGES:
                        # 🟢 USE RETRY WRAPPER HERE
                        success = update_with_retry("entities", {"details": cleaned}, row['id'])
                        if success:
                            # Optional: Small print to know it's working (can comment out for speed)
                            # print(f"      ✅ Fixed {row['name']}") 
                            total_cleaned += 1
                    else:
                        print(f"🔍 PREVIEW FIX: {row['name']}")
                        print(f"   BEFORE: {json.dumps(original)}")
                        print(f"   AFTER:  {json.dumps(cleaned)}")
                        total_cleaned += 1

            start += BATCH_SIZE
            
            # 🟢 Be polite to the database
            time.sleep(0.5) 

        except Exception as e:
            print(f"❌ CRITICAL ERROR fetching batch {start}: {e}")
            print("   Waiting 10 seconds before retrying batch...")
            time.sleep(10)
            # We don't increment 'start' so it will try this batch again

    print("\n------------------------------------------------")
    print(f"🎉 Done. Processed {total_cleaned} records.")

if __name__ == "__main__":
    run_cleanup()