from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from db_utils import supabase
import time
import re

# ===========================
# CONFIGURATION
# ===========================
COMMIT_CHANGES = True  # 🔴 Set to True to write to database
BATCH_SIZE = 1000

def setup_driver():
    chrome_options = Options()
    # chrome_options.add_argument("--headless") # Comment out to see it working
    chrome_options.add_argument("--log-level=3")
    chrome_options.add_argument("--window-size=1920,1080")
    prefs = {"credentials_enable_service": False, "profile.password_manager_enabled": False}
    chrome_options.add_experimental_option("prefs", prefs)
    service = Service(ChromeDriverManager().install())
    return webdriver.Chrome(service=service, options=chrome_options)

def handle_cookies(driver):
    try:
        banner_btn = WebDriverWait(driver, 2).until(
            EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Allow all cookies') or contains(text(), 'Accept')]"))
        )
        banner_btn.click()
        time.sleep(1.0)
    except Exception: pass

def get_wa_gender(driver, name):
    """
    Searches World Athletics and returns 'male', 'female', or None.
    """
    clean_name = name.replace("%20", " ")
    driver.get("https://worldathletics.org/athletes/search")
    handle_cookies(driver)
    
    try:
        # Find Search Box
        search_input = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "input[class*='AthleteSearch_searchInput'], input[type='search']"))
        )
        
        # Clear & Type
        search_input.click()
        search_input.send_keys(Keys.CONTROL + "a")
        search_input.send_keys(Keys.DELETE)
        search_input.send_keys(clean_name)
        time.sleep(0.5)
        search_input.send_keys(Keys.RETURN)
        
        # Wait for results
        first_name = clean_name.split()[0]
        WebDriverWait(driver, 5).until(
            EC.text_to_be_present_in_element((By.CSS_SELECTOR, "tbody"), first_name)
        )

        rows = driver.find_elements(By.CSS_SELECTOR, "tbody tr")
        
        # We check the first result that matches the name reasonably well
        for row in rows:
            cols = row.find_elements(By.TAG_NAME, "td")
            if len(cols) < 4: continue
            
            wa_name = driver.execute_script("return arguments[0].innerText;", cols[0]).strip()
            wa_sex = driver.execute_script("return arguments[0].innerText;", cols[2]).strip().lower()
            
            # Simple Name Check (First name must match)
            if first_name.lower() in wa_name.lower():
                if "women" in wa_sex or "female" in wa_sex: return "female"
                if "men" in wa_sex or "male" in wa_sex: return "male"
                
        return None

    except Exception:
        return None

def run_gender_cleanse():
    print(f"🤖 Starting Gender Cleanse (Commit: {COMMIT_CHANGES})...")
    
    driver = setup_driver()
    start = 0
    total_fixed = 0
    
    while True:
        # Fetch batch
        # You can add .is_("gender", "null") to only target missing ones
        res = supabase.table("entities")\
            .select("id, name, gender")\
            .range(start, start + BATCH_SIZE - 1)\
            .execute()
        
        rows = res.data
        if not rows: break
        
        print(f"   Processing rows {start} to {start + len(rows)}...")
        
        for row in rows:
            # OPTIONAL: Skip if gender looks fine already
            # if row['gender'] in ['male', 'female']: continue

            wa_gender = get_wa_gender(driver, row['name'])
            
            if wa_gender and wa_gender != row['gender']:
                print(f"   🔍 FIX: {row['name']} | Current: {row['gender']} -> New: {wa_gender}")
                
                if COMMIT_CHANGES:
                    supabase.table("entities").update({"gender": wa_gender}).eq("id", row['id']).execute()
                    print("      ✅ Saved.")
                
                total_fixed += 1
            elif not wa_gender:
                print(f"   ⚠️ Could not find gender for: {row['name']}")
            
            # Be polite
            time.sleep(0.5)
            
        start += BATCH_SIZE

    print(f"🎉 Done. Fixed {total_fixed} profiles.")
    driver.quit()

if __name__ == "__main__":
    run_gender_cleanse()